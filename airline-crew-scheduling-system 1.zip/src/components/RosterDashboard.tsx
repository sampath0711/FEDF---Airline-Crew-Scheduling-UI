import React, { useMemo } from "react";
import {
  Calendar,
  Users,
  Plane,
  FileText,
  AlertTriangle,
  Clock,
  ArrowRight,
  ShieldAlert,
  CheckCircle,
  XCircle,
  Bell,
  Check,
  UserCircle
} from "lucide-react";
import { Crew, Flight, LeaveRequest, Notification, User as UserType } from "../types";
import RosterHeatmap from "./RosterHeatmap";

interface RosterDashboardProps {
  crewList: Crew[];
  flights: Flight[];
  leaves: LeaveRequest[];
  notifications: Notification[];
  session: UserType;
  onUpdateCrew: (id: string, updates: Partial<Crew>) => Promise<any>;
  onMarkNotificationRead: (id: string) => void;
  onNavigateToTab: (tab: string) => void;
  onSelectFlight: (flightId: string) => void;
}

export default function RosterDashboard({
  crewList,
  flights,
  leaves,
  notifications,
  session,
  onUpdateCrew,
  onMarkNotificationRead,
  onNavigateToTab,
  onSelectFlight,
}: RosterDashboardProps) {
  // Statistics Computations
  const stats = useMemo(() => {
    const totalFlights = flights.length;
    const activeCrew = crewList.filter((c) => c.status === "Active").length;
    const restingCrew = crewList.filter((c) => c.status === "Resting").length;
    const leavesPending = leaves.filter((l) => l.status === "Pending").length;

    // Compliance estimation: flights with complete staffing
    let fullyStaffedCount = 0;
    flights.forEach((f) => {
      const assigned = crewList.filter((c) => f.assignedCrewIds.includes(c.id));
      const pilots = assigned.filter((c) => c.role === "Pilot").length;
      const cabin = assigned.filter((c) => c.role === "Cabin Crew").length;
      if (pilots >= f.requiredPilots && cabin >= f.requiredCabinCrew) {
        fullyStaffedCount++;
      }
    });
    const staffingPercentage = totalFlights
      ? Math.round((fullyStaffedCount / totalFlights) * 100)
      : 100;

    return {
      totalFlights,
      activeCrew,
      restingCrew,
      leavesPending,
      staffingPercentage,
    };
  }, [crewList, flights, leaves]);

  // Priority notifications
  const unreadNotifications = useMemo(() => {
    return notifications.filter((n) => !n.read).slice(0, 4);
  }, [notifications]);

  // Current session crew profile
  const currentUserCrew = useMemo(() => {
    if (!session?.crewId) return null;
    return crewList.find((c) => c.id === session.crewId) || null;
  }, [session, crewList]);

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-white/10 pb-5">
        <div>
          <h2 className="text-xl font-bold text-white tracking-tight">Roster Control Board</h2>
          <p className="text-xs text-slate-400 mt-1">
            Real-time visual monitoring of corporate flight dispatches and regulatory safety checks.
          </p>
        </div>
        <div className="text-xs font-mono text-slate-300 bg-white/5 px-3 py-1.5 rounded-lg border border-white/10 flex items-center gap-2">
          <Clock className="w-3.5 h-3.5 text-cyan-400 drop-shadow-[0_0_4px_rgba(34,211,238,0.4)]" />
          <span>System UTC: 2026-05-27 20:03</span>
        </div>
      </div>

      {/* Stats Bento Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        {/* Total Flights */}
        <div className="backdrop-blur-xl bg-white/5 border border-white/10 p-5 rounded-3xl flex items-center gap-4 hover:border-white/20 hover:bg-white/8 transition-all">
          <div className="w-11 h-11 bg-blue-500/10 text-blue-400 rounded-xl border border-blue-500/20 flex items-center justify-center">
            <Plane className="w-5.5 h-5.5" />
          </div>
          <div>
            <p className="text-[11px] font-semibold text-slate-450 uppercase tracking-wider">Scheduled Slots</p>
            <h3 className="text-xl font-bold text-white mt-0.5">{stats.totalFlights} Flights</h3>
          </div>
        </div>

        {/* Active Crew */}
        <div className="backdrop-blur-xl bg-white/5 border border-white/10 p-5 rounded-3xl flex items-center gap-4 hover:border-white/20 hover:bg-white/8 transition-all">
          <div className="w-11 h-11 bg-emerald-500/10 text-emerald-400 rounded-xl border border-emerald-500/20 flex items-center justify-center">
            <Users className="w-5.5 h-5.5" />
          </div>
          <div>
            <p className="text-[11px] font-semibold text-slate-450 uppercase tracking-wider">On-Duty Crew</p>
            <h3 className="text-xl font-bold text-white mt-0.5">{stats.activeCrew} Active</h3>
          </div>
        </div>

        {/* Resting Standby */}
        <div className="backdrop-blur-xl bg-white/5 border border-white/10 p-5 rounded-3xl flex items-center gap-4 hover:border-white/20 hover:bg-white/8 transition-all">
          <div className="w-11 h-11 bg-indigo-500/10 text-indigo-300 rounded-xl border border-indigo-500/20 flex items-center justify-center">
            <Clock className="w-5.5 h-5.5" />
          </div>
          <div>
            <p className="text-[11px] font-semibold text-slate-450 uppercase tracking-wider">Resting Standby</p>
            <h3 className="text-xl font-bold text-white mt-0.5">{stats.restingCrew} Crew</h3>
          </div>
        </div>

        {/* Leave Requests */}
        <div className="backdrop-blur-xl bg-white/5 border border-white/10 p-5 rounded-3xl flex items-center gap-4 hover:border-white/20 hover:bg-white/8 transition-all">
          <div className="w-11 h-11 bg-amber-500/10 text-amber-400 rounded-xl border border-amber-500/20 flex items-center justify-center font-bold">
            <FileText className="w-5.5 h-5.5" />
          </div>
          <div>
            <p className="text-[11px] font-semibold text-slate-450 uppercase tracking-wider">Pending Leaves</p>
            <h3 className="text-xl font-bold text-white mt-0.5">{stats.leavesPending} Petitions</h3>
          </div>
        </div>

        {/* Staffing Health Rate */}
        <div className="backdrop-blur-xl bg-gradient-to-tr from-blue-500/20 to-cyan-500/20 border border-cyan-500/30 p-5 rounded-3xl flex items-center gap-4 shadow-lg hover:border-cyan-500/40 transition-all">
          <div className="w-11 h-11 bg-cyan-400/20 text-cyan-300 rounded-xl flex items-center justify-center">
            <ShieldAlert className="w-5.5 h-5.5" />
          </div>
          <div>
            <p className="text-[10px] font-semibold text-slate-350 uppercase tracking-wide">Staffing Level</p>
            <h3 className="text-xl font-extrabold text-cyan-400 mt-0.5">{stats.staffingPercentage}%</h3>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-4 gap-6">
        {/* Personal Profile Section */}
        {currentUserCrew && (
          <div className="backdrop-blur-xl bg-white/5 border border-white/10 rounded-3xl p-6 shadow-xl xl:col-span-1 flex flex-col items-center text-center space-y-4">
            <div className="w-20 h-20 bg-gradient-to-tr from-cyan-400 to-blue-500 rounded-full p-0.5 shadow-[0_0_20px_rgba(34,211,238,0.3)]">
              <div className="w-full h-full bg-slate-900 rounded-full flex items-center justify-center">
                <UserCircle className="w-10 h-10 text-cyan-400" />
              </div>
            </div>
            
            <div>
              <h3 className="text-lg font-bold text-white">{currentUserCrew.name}</h3>
              <p className="text-[11px] text-cyan-400 uppercase tracking-wider font-semibold mt-1">
                {currentUserCrew.role} • {currentUserCrew.baseAirport}
              </p>
            </div>

            <div className="w-full max-w-xs space-y-3 pt-3">
              <div className="flex items-center justify-between text-xs text-slate-300">
                <span>Duty Hours This Week</span>
                <span className="font-mono text-white font-bold">{currentUserCrew.flightHoursThisWeek} / {currentUserCrew.maxWeeklyHours} h</span>
              </div>
              <div className="w-full bg-white/10 h-2 rounded-full overflow-hidden">
                <div 
                  className={`h-full rounded-full transition-all ${
                    (currentUserCrew.flightHoursThisWeek / currentUserCrew.maxWeeklyHours) > 0.85 
                    ? "bg-gradient-to-r from-orange-400 to-red-500" 
                    : "bg-gradient-to-r from-emerald-400 to-cyan-400"
                  }`} 
                  style={{ width: `${Math.min(100, (currentUserCrew.flightHoursThisWeek / currentUserCrew.maxWeeklyHours) * 100)}%` }}
                />
              </div>
              
              <div className="flex gap-2 w-full pt-2">
                <div className="flex-1 bg-white/5 border border-white/10 p-3 rounded-2xl flex flex-col items-center relative group">
                  <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wide">Status</span>
                  <select
                    value={currentUserCrew.status}
                    onChange={async (e) => {
                      try {
                        await onUpdateCrew(currentUserCrew.id, { status: e.target.value as any });
                      } catch(err) {
                        alert("Failed to update status");
                      }
                    }}
                    className={`mt-1 text-xs font-bold bg-transparent outline-none cursor-pointer appearance-none text-center ${currentUserCrew.status === 'Active' ? 'text-emerald-400' : currentUserCrew.status === 'Resting' ? 'text-indigo-400' : currentUserCrew.status === 'Travelling' ? 'text-blue-400' : 'text-slate-400'}`}
                  >
                    <option value="Active" className="bg-slate-900 text-emerald-400">Active</option>
                    <option value="Resting" className="bg-slate-900 text-indigo-400">Resting</option>
                    <option value="Travelling" className="bg-slate-900 text-blue-400">Travelling</option>
                    <option value="Standby" className="bg-slate-900 text-amber-400">Standby</option>
                    <option value="On Leave" className="bg-slate-900 text-slate-400">On Leave</option>
                  </select>
                </div>
                <div className="flex-1 bg-white/5 border border-white/10 p-3 rounded-2xl flex flex-col items-center">
                  <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wide">Flights</span>
                  <span className="text-xs font-bold text-slate-200 mt-1">
                    {flights.filter(f => f.assignedCrewIds.includes(currentUserCrew.id)).length} Active
                  </span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Heatmap Section */}
        <div className={`backdrop-blur-xl bg-white/5 border border-white/10 rounded-3xl p-5 shadow-xl ${currentUserCrew ? 'xl:col-span-3' : 'xl:col-span-4'}`}>
          <div className="flex items-center gap-2 mb-4">
            <Calendar className="w-5 h-5 text-cyan-400" />
            <h3 className="font-bold text-white">Duty Hours Visualizer (D3 Heatmap)</h3>
          </div>
          <p className="text-xs text-slate-400 mb-6">
            Real-time visualization of accumulated duty hours across team personnel. Red markers indicate max regulatory allowable hours per week.
          </p>
          <RosterHeatmap crewList={crewList} />
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Calendar Gantt Area */}
        <div className="backdrop-blur-xl bg-white/5 border border-white/10 rounded-3xl p-5 shadow-xl lg:col-span-2 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Calendar className="w-5 h-5 text-cyan-400 drop-shadow-[0_0_4px_rgba(34,211,238,0.3)]" />
              <h3 className="font-bold text-white">Flight Rotation Timeline</h3>
            </div>
            <span className="text-[10px] font-bold bg-white/10 text-slate-300 px-2 py-1 rounded-md uppercase border border-white/5">
              May 28 - May 29
            </span>
          </div>

          <div className="space-y-3">
            {flights.map((flight) => {
              const assignedCount = flight.assignedCrewIds.length;
              const isStaffed =
                flight.assignedCrewIds.filter(
                  (cid) => crewList.find((c) => c.id === cid)?.role === "Pilot"
                ).length >= flight.requiredPilots &&
                flight.assignedCrewIds.filter(
                  (cid) => crewList.find((c) => c.id === cid)?.role === "Cabin Crew"
                ).length >= flight.requiredCabinCrew;

              return (
                <div
                  key={flight.id}
                  className="p-4 bg-white/[0.02] border border-white/5 hover:border-white/15 hover:bg-white/5 rounded-2xl transition-all cursor-pointer"
                  onClick={() => onSelectFlight(flight.id)}
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div className="flex items-center gap-2.5">
                      <div className="w-9 h-9 bg-cyan-400/10 border border-cyan-400/20 rounded-xl flex items-center justify-center font-bold text-xs text-cyan-400 shadow-md">
                        {flight.flightNumber.split("-")[1] || flight.flightNumber}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-white text-sm">
                            {flight.flightNumber}
                          </span>
                          <span className="text-[10px] font-semibold bg-white/10 text-slate-300 px-1.5 py-0.5 rounded">
                            {flight.aircraftType}
                          </span>
                        </div>
                        <div className="text-xs text-slate-400 mt-0.5 flex items-center gap-2">
                          <span className="font-semibold text-slate-200">{flight.origin}</span>
                          <ArrowRight className="w-3 h-3 text-cyan-400/60" />
                          <span className="font-semibold text-slate-200">{flight.destination}</span>
                        </div>
                      </div>
                    </div>

                    <div className="flex flex-wrap items-center gap-3">
                      {/* Timeline clock bar */}
                      <div className="text-right">
                        <div className="text-xs font-semibold text-slate-200 flex items-center gap-1.5 justify-end">
                          <Clock className="w-3" />
                          <span>
                            {new Date(flight.departureTime).toLocaleTimeString([], {
                              hour: "2-digit",
                              minute: "2-digit",
                              timeZone: "UTC",
                            })}
                          </span>
                        </div>
                        <span className="text-[10px] text-slate-400">Scheduled Departure UTC</span>
                      </div>

                      {/* Staffing indicator */}
                      <div className="flex items-center gap-2">
                        <div className="text-right">
                          <span
                            className={`text-xs font-bold ${
                              isStaffed ? "text-emerald-400" : "text-amber-400"
                            }`}
                          >
                            {assignedCount} Crew
                          </span>
                          <div className="text-[10px] text-slate-400">
                            Req: {flight.requiredPilots}P/{flight.requiredCabinCrew}C
                          </div>
                        </div>
                        <div>
                          {isStaffed ? (
                            <div className="w-5 h-5 bg-emerald-500/15 text-emerald-400 rounded-full flex items-center justify-center border border-emerald-500/25">
                              <CheckCircle className="w-3.5 h-3.5" />
                            </div>
                          ) : (
                            <div className="w-5 h-5 bg-amber-500/15 text-amber-400 rounded-full flex items-center justify-center border border-amber-500/25">
                              <AlertTriangle className="w-3.5 h-3.5" />
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Gantt progress visual bar */}
                  <div className="mt-3.5 w-full bg-white/5 rounded-full h-1.5 overflow-hidden">
                    <div
                      className={`h-full rounded-full ${
                        isStaffed ? "bg-gradient-to-r from-emerald-500 to-teal-400" : "bg-gradient-to-r from-amber-500 to-orange-400"
                      }`}
                      style={{
                        width: `${Math.min(
                          (assignedCount / (flight.requiredPilots + flight.requiredCabinCrew)) * 100,
                          100
                        )}%`,
                      }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Notifications & System Updates sidebar */}
        <div className="backdrop-blur-xl bg-white/5 border border-white/10 rounded-3xl p-5 shadow-xl space-y-4">
          <div className="flex items-center justify-between border-b border-white/10 pb-3">
            <div className="flex items-center gap-2">
              <Bell className="w-5 h-5 text-cyan-400" />
              <h3 className="font-bold text-white">Operational Alerts</h3>
            </div>
            {unreadNotifications.length > 0 && (
              <span className="bg-red-500/20 text-red-400 text-[10px] font-bold px-2 py-0.5 rounded-full border border-red-500/25 animate-pulse">
                {unreadNotifications.length} New
              </span>
            )}
          </div>

          <div className="space-y-3 font-sans">
            {unreadNotifications.length === 0 ? (
              <div className="text-center py-8 text-slate-400">
                <CheckCircle className="w-8 h-8 text-slate-500 mx-auto mb-2" />
                <p className="text-xs">No active conflicts detected.</p>
                <p className="text-[10px] text-slate-500 mt-1">Schedules comply with legal rest hours.</p>
              </div>
            ) : (
              unreadNotifications.map((notif) => (
                <div
                  key={notif.id}
                  className={`p-3 rounded-xl border flex items-start gap-2.5 transition-all ${
                    notif.severity === "error"
                      ? "bg-red-500/10 border-red-500/20"
                      : notif.severity === "warning"
                      ? "bg-amber-500/10 border-amber-500/20"
                      : "bg-cyan-500/10 border-cyan-500/20"
                  }`}
                >
                  <div className="mt-0.5 shrink-0">
                    {notif.severity === "error" ? (
                      <XCircle className="w-4 h-4 text-red-400" />
                    ) : notif.severity === "warning" ? (
                      <AlertTriangle className="w-4 h-4 text-amber-400" />
                    ) : (
                      <ShieldAlert className="w-4 h-4 text-cyan-400" />
                    )}
                  </div>
                  <div className="flex-1 space-y-0.5">
                    <div className="flex justify-between items-start gap-2">
                      <span className="text-xs font-bold text-slate-155 text-white">{notif.title}</span>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onMarkNotificationRead(notif.id);
                        }}
                        className="p-0.5 hover:bg-white/10 border border-white/5 hover:border-white/20 rounded text-slate-400 hover:text-white transition-all cursor-pointer"
                        title="Dismiss alert"
                      >
                        <Check className="w-3 h-3" />
                      </button>
                    </div>
                    <p className="text-[11px] text-slate-300 leading-relaxed font-sans">{notif.message}</p>
                    <div className="text-[9px] text-slate-500 mt-1 uppercase tracking-wider font-semibold font-mono">
                      {new Date(notif.timestamp).toLocaleTimeString([], {
                        hour: "2-digit",
                        minute: "2-digit",
                      })}
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>

          <button
            onClick={() => onNavigateToTab("Dispatch")}
            className="w-full py-2.5 bg-white/5 hover:bg-white/10 hover:text-cyan-400 border border-white/10 rounded-xl text-xs font-bold text-slate-200 text-center block transition-all hover:shadow-lg cursor-pointer"
          >
            Review Staff Assignments &rarr;
          </button>
        </div>
      </div>
    </div>
  );
}
