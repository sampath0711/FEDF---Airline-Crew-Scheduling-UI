import React, { useEffect, useRef } from "react";
import * as d3 from "d3";
import { Crew } from "../types";

interface RosterHeatmapProps {
  crewList: Crew[];
}

export default function RosterHeatmap({ crewList }: RosterHeatmapProps) {
  const svgRef = useRef<SVGSVGElement>(null);

  useEffect(() => {
    if (!svgRef.current || !crewList.length) return;

    const width = 800;
    const height = Math.max(300, crewList.length * 30 + 60);
    const margin = { top: 30, right: 30, bottom: 30, left: 150 };
    const innerWidth = width - margin.left - margin.right;
    const innerHeight = height - margin.top - margin.bottom;

    // Clear previous SVG contents
    d3.select(svgRef.current).selectAll("*").remove();

    const svg = d3
      .select(svgRef.current)
      .attr("viewBox", `0 0 ${width} ${height}`)
      .attr("width", "100%")
      .attr("height", "100%");

    const g = svg
      .append("g")
      .attr("transform", `translate(${margin.left},${margin.top})`);

    // We visualize flight hours for current week across all crew.
    // X-axis: Hours (0 to 120 approx max)
    // Y-axis: Crew Members
    
    // X scale
    const x = d3.scaleLinear()
      .domain([0, d3.max(crewList, (d) => Math.max(60, d.flightHoursThisWeek)) || 60])
      .range([0, innerWidth]);

    // Y scale
    const y = d3.scaleBand()
      .domain(crewList.map(d => d.name))
      .range([0, innerHeight])
      .padding(0.2);

    // Color scale for intensity
    const colorScale = d3.scaleSequential()
      .domain([0, 60])
      .interpolator(d3.interpolatePuBuGn);

    // X Axis
    g.append("g")
      .attr("transform", `translate(0,${innerHeight})`)
      .call(d3.axisBottom(x).ticks(10))
      .attr("color", "#94a3b8")
      .selectAll("text")
      .style("font-size", "10px")
      .style("font-family", "sans-serif");

    // Y Axis
    g.append("g")
      .call(d3.axisLeft(y).tickSize(0))
      .attr("color", "#cbd5e1")
      .selectAll("text")
      .style("font-size", "11px")
      .style("font-family", "sans-serif")
      .attr("dx", "-10");

    // Bars/Heatmap items
    g.selectAll(".bar")
      .data(crewList)
      .enter()
      .append("rect")
      .attr("class", "bar")
      .attr("y", d => y(d.name) || 0)
      .attr("height", y.bandwidth())
      .attr("x", 0)
      .attr("width", 0) // Start at zero for animation
      .attr("fill", d => {
        if (d.flightHoursThisWeek >= d.maxWeeklyHours * 0.85) {
          return "#ef4444"; // red-500
        }
        return colorScale(d.flightHoursThisWeek) as string;
      })
      .attr("rx", 4)
      .transition()
      .duration(1000)
      .ease(d3.easeCubicOut)
      .attr("width", d => x(d.flightHoursThisWeek));

    // Data labels on bars
    g.selectAll(".label")
      .data(crewList)
      .enter()
      .append("text")
      .attr("class", "label")
      .attr("y", d => (y(d.name) || 0) + y.bandwidth() / 2)
      .attr("x", 0) // Start at 0 for animation sync
      .attr("dy", "0.35em")
      .attr("dx", "5")
      .attr("fill", "#0f172a")
      .style("font-size", "10px")
      .style("font-weight", "bold")
      .style("opacity", 0)
      .text(d => `${d.flightHoursThisWeek}h`)
      .transition()
      .duration(1000)
      .ease(d3.easeCubicOut)
      .attr("x", d => x(d.flightHoursThisWeek))
      .style("opacity", 1);
      
    // Max Weekly limit line
    g.selectAll(".limit-line")
      .data(crewList)
      .enter()
      .append("line")
      .attr("x1", d => x(d.maxWeeklyHours))
      .attr("x2", d => x(d.maxWeeklyHours))
      .attr("y1", d => y(d.name) || 0)
      .attr("y2", d => (y(d.name) || 0) + y.bandwidth())
      .attr("stroke", "#ef4444") // Red limit line
      .attr("stroke-width", 2)
      .attr("stroke-dasharray", "2,2")
      .style("opacity", 0)
      .transition()
      .duration(1000)
      .style("opacity", 1);


  }, [crewList]);

  return (
    <div className="w-full overflow-x-auto overflow-y-hidden">
      <svg ref={svgRef}></svg>
    </div>
  );
}
