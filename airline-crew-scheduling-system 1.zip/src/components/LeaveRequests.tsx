import React, { useState } from "react";
import {
  FileText,
  Calendar,
  User,
  Plus,
  Check,
  X,
  AlertCircle,
  Clock,
  History,
  Plane
} from "lucide-react";
import { LeaveRequest, Crew } from "../types";

interface LeaveRequestsProps {
  leaves: LeaveRequest[];
  crewList: Crew[];
  onAddNewLeave: (leaveData: Partial<LeaveRequest>) => Promise<any>;
  onResolveLeave: (id: string, action: "Approved" | "Rejected") => Promise<any>;
  currentUserRole: string;
  linkCrewId?: string;
}

export default function LeaveRequests({
  leaves,
  crewList,
  onAddNewLeave,
  onResolveLeave,
  currentUserRole,
  linkCrewId,
}: LeaveRequestsProps) {
  // Form State for Crew Members
  const [isAdding, setIsAdding] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    type: "Annual",
    startDate: "2026-05-30",
    endDate: "2026-06-03",
    reason: "",
  });

  const matchedCrew = crewList.find((c) => c.id === linkCrewId);

  // Sorters
  const filteredLeaves = leaves.filter((l) => {
    if (currentUserRole === "Crew") {
      return l.crewId === linkCrewId;
    }
    return true; // Admin views all
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    const start = new Date(formData.startDate).getTime();
    const end = new Date(formData.endDate).getTime();

    if (start >= end) {
      setFormError("Leave end date must occur after the start date.");
      return;
    }

    if (!formData.reason.trim()) {
      setFormError("A brief explanation is mandatory.");
      return;
    }

    setSubmitting(true);
    try {
      await onAddNewLeave({
        crewId: linkCrewId!,
        type: formData.type as any,
        startDate: formData.startDate,
        endDate: formData.endDate,
        reason: formData.reason,
      });
      setIsAdding(false);
      setFormData({
        type: "Annual",
        startDate: "2026-05-30",
        endDate: "2026-06-03",
        reason: "",
      });
    } catch (err: any) {
      setFormError(err.message || "Failed to catalog leave request.");
    } finally {
      setSubmitting(false);
    }
  };

  const handleAction = async (id: string, action: "Approved" | "Rejected") => {
    try {
      await onResolveLeave(id, action);
    } catch (err: any) {
      alert(err.message || "Approval transaction failure.");
    }
  };

  return (
    <div className="space-y-6 font-sans">
      {/* Header and triggers */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/10 pb-5">
        <div>
          <h2 className="text-xl font-extrabold text-white tracking-tight">Time-Off &amp; Leave Registry</h2>
          <p className="text-xs text-slate-400 mt-1">
            {currentUserRole === "Admin"
              ? "Review personnel rest applications, analyze staffing impact, and authorize flight exemptions."
              : "Track personal leave approvals, submit medical/rest notifications, and audit historic claims."}
          </p>
        </div>
        {currentUserRole === "Crew" && (
          <button
            onClick={() => setIsAdding(true)}
            className="bg-gradient-to-r from-blue-500 to-cyan-500 hover:opacity-90 text-white font-bold text-xs py-2.5 px-4 rounded-xl shadow-lg shadow-cyan-500/10 active:scale-[0.98] transition-all cursor-pointer flex items-center gap-2 self-start sm:self-center"
          >
            <Plus className="w-4 h-4" />
            File Leave Petition
          </button>
        )}
      </div>

      {/* Roster overview widgets for crew member profile if role is 'Crew' */}
      {currentUserRole === "Crew" && matchedCrew && (
        <div className="p-4 backdrop-blur-xl bg-white/5 border border-white/10 rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className={`w-10 h-10 rounded-xl shadow-sm text-white flex items-center justify-center font-bold text-sm ${matchedCrew.avatarColor}`}>
              {matchedCrew.name.split(" ").pop()?.charAt(0)}
            </div>
            <div>
              <h4 className="font-bold text-white text-xs">Roster Standby: {matchedCrew.name}</h4>
              <p className="text-[10px] text-slate-400 mt-0.5">Role: {matchedCrew.rank} • Base: {matchedCrew.baseAirport}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-[10px] uppercase font-bold text-slate-350">Roster Status:</span>
            <span className="text-xs font-bold text-cyan-400 bg-cyan-400/10 px-2 py-0.5 rounded border border-cyan-455/20">
              {matchedCrew.status}
            </span>
          </div>
        </div>
      )}

      {/* Leave Application Popover Box */}
      {isAdding && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
          <div className="backdrop-blur-3xl bg-slate-900/90 border border-white/10 rounded-3xl p-6 shadow-2xl max-w-md w-full relative">
            <button
              onClick={() => setIsAdding(false)}
              className="absolute top-4 right-4 p-1.5 rounded-lg hover:bg-white/10 text-slate-400 hover:text-white transition-all cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <h3 className="font-bold text-white text-base mb-1">Submit Leave Claim</h3>
            <p className="text-xs text-slate-400 mb-6 font-sans">File corporate claim petition with explanation.</p>

            {formError && (
              <div className="mb-4 p-3 backdrop-blur-md bg-red-500/10 border border-red-500/20 text-red-200 rounded-xl text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{formError}</span>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4 font-sans text-left">
              <div>
                <label className="block text-[10px] uppercase font-bold text-slate-350 mb-1">Claim Type</label>
                <select
                  id="leave-type"
                  value={formData.type}
                  onChange={(e) => setFormData({ ...formData, type: e.target.value })}
                  className="w-full bg-white/5 border border-white/10 rounded-xl py-2 px-3 text-xs text-slate-200 outline-none focus:border-cyan-400"
                >
                  <option value="Annual" className="bg-slate-950">Annual Paid Leave</option>
                  <option value="Medical" className="bg-slate-950">Medical / Sick Off</option>
                  <option value="Personal" className="bg-slate-950">Personal Rest Claim</option>
                  <option value="Other" className="bg-slate-950">Other / Compassionate</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] uppercase font-bold text-slate-350 mb-1">Start Date</label>
                  <input
                    id="leave-start-date"
                    type="date"
                    required
                    value={formData.startDate}
                    onChange={(e) => setFormData({ ...formData, startDate: e.target.value })}
                    className="w-full bg-white/5 border border-white/10 rounded-xl py-2 px-3 text-xs text-white outline-none focus:border-cyan-400 focus:bg-white/10 transition-all"
                  />
                </div>

                <div>
                  <label className="block text-[10px] uppercase font-bold text-slate-355 mb-1">End Date (Inclusive)</label>
                  <input
                    id="leave-end-date"
                    type="date"
                    required
                    value={formData.endDate}
                    onChange={(e) => setFormData({ ...formData, endDate: e.target.value })}
                    className="w-full bg-white/5 border border-white/10 rounded-xl py-2 px-3 text-xs text-white outline-none focus:border-cyan-400 focus:bg-white/10 transition-all font-sans"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] uppercase font-bold text-slate-350 mb-1">Reason / Justification</label>
                <textarea
                  id="leave-reason"
                  rows={3}
                  required
                  value={formData.reason}
                  onChange={(e) => setFormData({ ...formData, reason: e.target.value })}
                  placeholder="Provide supporting notes or medical reference identifier details..."
                  className="w-full bg-white/5 border border-white/10 rounded-xl py-2 px-3 text-xs text-white placeholder-white/20 outline-none focus:border-cyan-400 focus:bg-white/10 font-sans"
                />
              </div>

              <div className="flex gap-3 pt-4">
                <button
                  type="button"
                  onClick={() => setIsAdding(false)}
                  className="flex-1 bg-white/5 border border-white/10 hover:bg-white/10 rounded-xl py-2.5 text-xs font-bold text-slate-300 transition-all cursor-pointer text-center"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="flex-1 bg-gradient-to-r from-blue-500 to-cyan-500 hover:opacity-90 rounded-xl py-2.5 text-xs font-bold text-white transition-all cursor-pointer text-center flex items-center justify-center shadow-lg shadow-cyan-500/10"
                >
                  {submitting ? "Submitting Request..." : "File Petition"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Main requests tables list */}
      <div className="backdrop-blur-xl bg-white/5 border border-white/10 rounded-3xl p-5 shadow-xl overflow-hidden">
        <div className="flex items-center gap-2 mb-4 border-b border-white/10 pb-3">
          <History className="w-5 h-5 text-cyan-400" />
          <h3 className="font-bold text-white text-sm">Petition Records History</h3>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-white/10 text-slate-400 font-extrabold uppercase tracking-wide">
                <th className="py-3 px-4">Personnel Claim</th>
                <th className="py-3 px-4">Role</th>
                <th className="py-3 px-4">Claim Category</th>
                <th className="py-3 px-4">Duration Range</th>
                <th className="py-3 px-4">Justification Notes</th>
                <th className="py-3 px-4">Transaction Status</th>
                {currentUserRole === "Admin" && <th className="py-3 px-4 text-right">Decisions Action</th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {filteredLeaves.length === 0 ? (
                <tr>
                  <td colSpan={currentUserRole === "Admin" ? 7 : 6} className="py-8 text-center text-slate-400">
                    No active leave records filed.
                  </td>
                </tr>
              ) : (
                filteredLeaves.map((request) => {
                  const getStatusStyle = (status: string) => {
                    switch (status) {
                      case "Approved":
                        return "text-emerald-400 bg-emerald-500/15 border border-emerald-500/20";
                      case "Rejected":
                        return "text-rose-400 bg-rose-500/15 border border-rose-500/20";
                      default:
                        return "text-amber-400 bg-amber-500/15 border border-amber-500/20 animate-pulse";
                    }
                  };

                  return (
                    <tr key={request.id} className="hover:bg-white/[0.015] transition-colors">
                      <td className="py-4 px-4 font-bold text-white">{request.crewName}</td>
                      <td className="py-4 px-4 font-semibold text-slate-400">{request.crewRole}</td>
                      <td className="py-4 px-4 font-bold text-cyan-405">{request.type}</td>
                      <td className="py-4 px-4 text-slate-300 leading-relaxed font-mono">
                        <div>From: {request.startDate}</div>
                        <div>Till: {request.endDate}</div>
                      </td>
                      <td className="py-4 px-4 text-slate-300 max-w-xs truncate" title={request.reason}>
                        {request.reason}
                      </td>
                      <td className="py-4 px-4 whitespace-nowrap">
                        <span className={`px-2.5 py-1 border text-[10px] font-bold rounded-full ${getStatusStyle(request.status)}`}>
                          {request.status}
                        </span>
                      </td>

                      {currentUserRole === "Admin" && (
                        <td className="py-4 px-4 text-right whitespace-nowrap">
                          {request.status === "Pending" ? (
                            <div className="flex justify-end gap-2 text-right">
                              <button
                                onClick={() => handleAction(request.id, "Rejected")}
                                className="p-1 px-2 backdrop-blur-md bg-rose-500/5 hover:bg-rose-500/15 border border-rose-500/20 hover:border-rose-500/30 text-rose-450 hover:text-rose-350 rounded-lg text-[10px] font-bold transition-all flex items-center gap-1 cursor-pointer font-sans"
                                title="Reject application"
                              >
                                <X className="w-3.5 h-3.5" /> Reject
                              </button>
                              <button
                                onClick={() => handleAction(request.id, "Approved")}
                                className="p-1 px-2.5 bg-emerald-500/10 hover:bg-emerald-500 text-emerald-400 hover:text-white border border-emerald-500/20 hover:border-emerald-500 transition-all flex items-center gap-1 cursor-pointer font-sans"
                                title="Authorize and approve"
                              >
                                <Check className="w-3.5 h-3.5" /> Approve
                              </button>
                            </div>
                          ) : (
                            <span className="text-[10px] text-slate-500 font-semibold font-mono uppercase tracking-wider">Processed</span>
                          )}
                        </td>
                      )}
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
