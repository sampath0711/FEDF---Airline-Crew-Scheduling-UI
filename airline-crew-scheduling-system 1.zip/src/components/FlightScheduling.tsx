import React, { useState, useMemo } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Calendar,
  Plus,
  PlaneTakeoff,
  PlaneLanding,
  ArrowRight,
  ShieldCheck,
  Users,
  Search,
  UserPlus,
  UserMinus,
  AlertTriangle,
  FileMinus,
  Clock,
  X,
  PlusCircle,
  HelpCircle
} from "lucide-react";
import { Crew, Flight } from "../types";

interface FlightSchedulingProps {
  flights: Flight[];
  crewList: Crew[];
  onAddFlight: (flightData: Partial<Flight>) => Promise<any>;
  onAssignCrew: (flightId: string, crewId: string, override?: boolean) => Promise<any>;
  currentUserRole: string;
  selectedFlightId?: string;
  onClearSelectedFlight: () => void;
  onSelectFlight: (id: string) => void;
}

export default function FlightScheduling({
  flights,
  crewList,
  onAddFlight,
  onAssignCrew,
  currentUserRole,
  selectedFlightId,
  onClearSelectedFlight,
  onSelectFlight,
}: FlightSchedulingProps) {
  // Filters
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("All");

  // Form toggles
  const [isAdding, setIsAdding] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    flightNumber: "",
    origin: "LAX",
    destination: "JFK",
    departureTime: "2026-05-28T12:00",
    arrivalTime: "2026-05-28T18:00",
    requiredPilots: "2",
    requiredCabinCrew: "3",
    aircraftType: "Boeing 737 Max",
  });

  // Assign Warning Toggle
  const [conflictWarning, setConflictWarning] = useState<{
    crewId: string;
    crewName: string;
    flightId: string;
    message: string;
    type: string;
  } | null>(null);

  // Filter flights
  const filteredFlights = useMemo(() => {
    return flights.filter((f) => {
      const matchSearch =
        f.flightNumber.toLowerCase().includes(search.toLowerCase()) ||
        f.origin.toLowerCase().includes(search.toLowerCase()) ||
        f.destination.toLowerCase().includes(search.toLowerCase()) ||
        f.aircraftType.toLowerCase().includes(search.toLowerCase());

      const matchStatus = statusFilter === "All" || f.status === statusFilter;
      return matchSearch && matchStatus;
    });
  }, [flights, search, statusFilter]);

  // Selected Flight Object
  const selectedFlight = useMemo(() => {
    return flights.find((f) => f.id === selectedFlightId);
  }, [flights, selectedFlightId]);

  // Sorter helpers
  const assignedCrewList = useMemo(() => {
    if (!selectedFlight) return [];
    return crewList.filter((c) => selectedFlight.assignedCrewIds.includes(c.id));
  }, [crewList, selectedFlight]);

  // Standby available crew list
  const eligibleStandbyCrew = useMemo(() => {
    if (!selectedFlight) return [];
    // Crew not assigned to this flight
    return crewList.filter((c) => !selectedFlight.assignedCrewIds.includes(c.id));
  }, [crewList, selectedFlight]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    const dep = new Date(formData.departureTime).getTime();
    const arr = new Date(formData.arrivalTime).getTime();

    if (dep >= arr) {
      setFormError("Arrival time must be strictly after departure time.");
      return;
    }

    setSubmitting(true);
    try {
      // Reformat dates to standard ISO strings
      await onAddFlight({
        ...formData,
        departureTime: new Date(formData.departureTime).toISOString(),
        arrivalTime: new Date(formData.arrivalTime).toISOString(),
        requiredPilots: Number(formData.requiredPilots),
        requiredCabinCrew: Number(formData.requiredCabinCrew),
      });
      setIsAdding(false);
      setFormData({
        flightNumber: "",
        origin: "LAX",
        destination: "JFK",
        departureTime: "2026-05-28T12:00",
        arrivalTime: "2026-05-28T18:00",
        requiredPilots: "2",
        requiredCabinCrew: "3",
        aircraftType: "Boeing 737 Max",
      });
    } catch (err: any) {
      setFormError(err.message || "Failed to dispatch flight slot.");
    } finally {
      setSubmitting(false);
    }
  };

  const handleCrewAssignmentToggle = async (crewId: string, override = false) => {
    if (!selectedFlightId) return;
    setConflictWarning(null);

    const crewMember = crewList.find((c) => c.id === crewId);
    if (!crewMember) return;

    try {
      await onAssignCrew(selectedFlightId, crewId, override);
    } catch (err: any) {
      if (err.conflict) {
        // High visibility conflict warnings with override opportunities
        setConflictWarning({
          crewId,
          crewName: crewMember.name,
          flightId: selectedFlightId,
          message: err.message,
          type: err.type,
        });
      } else {
        alert(err.message || "Error assigning crew.");
      }
    }
  };

  const handleApplyOverride = async () => {
    if (!conflictWarning) return;
    const { crewId, flightId } = conflictWarning;
    await handleCrewAssignmentToggle(crewId, true);
    setConflictWarning(null);
  };

  const handleEmergencyAssign = async () => {
    if (!selectedFlightId || eligibleStandbyCrew.length === 0) return;
    const crewMember = eligibleStandbyCrew[0];
    await handleCrewAssignmentToggle(crewMember.id, true);
  };

  return (
    <div className="grid grid-cols-1 xl:grid-cols-3 gap-6 font-sans">
      {/* Primary Flight schedule listings */}
      <div className="xl:col-span-2 space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/10 pb-5">
          <div>
            <h2 className="text-xl font-bold text-white tracking-tight">Commercial Flight Dispatch</h2>
            <p className="text-xs text-slate-400 mt-1">
              Add new commercial rotations, audit required staffing levels, and review current crew assignments.
            </p>
          </div>
          {currentUserRole === "Admin" && (
            <button
              onClick={() => setIsAdding(true)}
              className="bg-gradient-to-r from-blue-500 to-cyan-500 hover:opacity-90 text-white font-bold text-xs py-2.5 px-4 rounded-xl shadow-lg shadow-cyan-500/10 active:scale-[0.98] transition-all cursor-pointer flex items-center gap-2"
            >
              <PlusCircle className="w-4 h-4" />
              Dispatch Flight Router
            </button>
          )}
        </div>

        {/* Filters */}
        <div className="backdrop-blur-xl bg-white/5 border border-white/10 rounded-2xl p-4 flex flex-col sm:flex-row items-center gap-4">
          <div className="relative w-full sm:flex-1">
            <span className="absolute left-3 top-3 text-slate-450">
              <Search className="w-4.5 h-4.5" />
            </span>
            <input
              id="flight-search"
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search by flight code or departure/destination route..."
              className="w-full bg-white/5 border border-white/10 text-white placeholder-white/20 focus:border-cyan-405/80 focus:bg-white/10 focus:ring-1 focus:ring-cyan-500/20 rounded-xl py-2 pl-10 pr-4 text-xs tracking-wide focus:outline-none transition-all"
            />
          </div>

          <select
            id="flight-status"
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="w-full sm:w-40 bg-white/5 border border-white/10 rounded-xl px-2.5 py-1.5 text-xs text-slate-200 outline-none focus:border-cyan-400 focus:bg-slate-900"
          >
            <option value="All" className="bg-slate-950">All Statuses</option>
            <option value="On Time" className="bg-slate-950">On Time Only</option>
            <option value="Delayed" className="bg-slate-950">Delayed</option>
            <option value="Cancelled" className="bg-slate-950">Cancelled</option>
            <option value="In-Flight" className="bg-slate-950">In Flight</option>
            <option value="Arrived" className="bg-slate-950">Arrived</option>
          </select>
        </div>

        {/* Grid List */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <AnimatePresence mode="popLayout">
            {filteredFlights.map((flight) => {
              const isSelected = flight.id === selectedFlightId;
              const assignedPilots = crewList.filter(
                (c) => flight.assignedCrewIds.includes(c.id) && c.role === "Pilot"
              ).length;
              const assignedCabin = crewList.filter(
                (c) => flight.assignedCrewIds.includes(c.id) && c.role === "Cabin Crew"
              ).length;

              const pilotStatusValid = assignedPilots >= flight.requiredPilots;
              const cabinStatusValid = assignedCabin >= flight.requiredCabinCrew;
              const fullStaffStatus = pilotStatusValid && cabinStatusValid;

              return (
                <motion.div
                  layout
                  initial={{ opacity: 0, scale: 0.95, y: 10 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.95, y: -10 }}
                  transition={{ duration: 0.2 }}
                  key={flight.id}
                  onClick={() => onSelectFlight(flight.id)}
                  className={`backdrop-blur-xl border rounded-3xl p-5 cursor-pointer space-y-4 transition-all relative ${
                    isSelected
                      ? "border-cyan-450 bg-white/10 shadow-lg shadow-cyan-500/5 ring-1 ring-cyan-500/20"
                      : "border-white/10 bg-white/5 hover:border-white/20 hover:bg-white/8"
                  }`}
                >
                  <div className="flex justify-between items-center">
                    <div className="flex items-center gap-2">
                      <span className="font-extrabold text-sm text-white">{flight.flightNumber}</span>
                      <span className="text-[9px] uppercase font-bold text-slate-300 tracking-wide font-mono bg-white/10 px-1.5 py-0.5 rounded border border-white/5">
                        {flight.aircraftType}
                      </span>
                    </div>
                    <span
                      className={`text-[9px] uppercase font-extrabold px-2.5 py-0.5 rounded-full border ${
                        flight.status === "On Time"
                          ? "text-emerald-400 bg-emerald-500/10 border-emerald-500/20"
                          : flight.status === "Delayed"
                          ? "text-amber-400 bg-amber-500/10 border-amber-500/20"
                          : flight.status === "Cancelled"
                          ? "text-red-400 bg-red-500/10 border-red-500/20"
                          : "text-slate-300 bg-white/5 border-white/10"
                      }`}
                    >
                      {flight.status}
                    </span>
                  </div>

                  <div className="grid grid-cols-5 items-center gap-2">
                    <div className="col-span-2">
                      <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wide">Takeoff</p>
                      <div className="font-extrabold text-white text-sm">{flight.origin}</div>
                      <div className="text-[10px] text-slate-355 leading-none mt-1">
                        {new Date(flight.departureTime).toLocaleTimeString([], {
                          hour: "2-digit",
                          minute: "2-digit",
                          timeZone: "UTC",
                        })}{" "}
                        UTC
                      </div>
                    </div>

                    <div className="col-span-1 flex justify-center text-slate-400">
                      <ArrowRight className="w-5 h-5 text-cyan-400/50" />
                    </div>

                    <div className="col-span-2 text-right">
                      <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wide">Destination</p>
                      <div className="font-extrabold text-white text-sm">{flight.destination}</div>
                      <div className="text-[10px] text-slate-355 leading-none mt-1">
                        {new Date(flight.arrivalTime).toLocaleTimeString([], {
                          hour: "2-digit",
                          minute: "2-digit",
                          timeZone: "UTC",
                        })}{" "}
                        UTC
                      </div>
                    </div>
                  </div>

                  {/* Staffing levels widgets */}
                  <div className="border-t border-dashed border-white/5 pt-3 flex items-center justify-between text-xs">
                    <div className="flex gap-3">
                      <div className="flex items-center gap-1">
                        <span className="font-semibold text-slate-400 font-mono">P:</span>
                        <span
                          className={`font-black font-mono ${
                            pilotStatusValid ? "text-emerald-400" : "text-red-400"
                          }`}
                        >
                          {assignedPilots}/{flight.requiredPilots}
                        </span>
                      </div>
                      <div className="flex items-center gap-1">
                        <span className="font-semibold text-slate-400 font-mono">CC:</span>
                        <span
                          className={`font-black font-mono ${
                            cabinStatusValid ? "text-emerald-400" : "text-amber-400"
                          }`}
                        >
                          {assignedCabin}/{flight.requiredCabinCrew}
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5 text-[10px] font-bold">
                      {fullStaffStatus ? (
                        <span className="text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-md flex items-center gap-1 border border-emerald-500/20">
                          <ShieldCheck className="w-3.5 h-3.5" /> Fully Staffed
                        </span>
                      ) : (
                        <span className="text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded-md flex items-center gap-1 border border-amber-500/20">
                          <AlertTriangle className="w-3.5 h-3.5 animate-pulse" /> Warning: Unfilled
                        </span>
                      )}
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </AnimatePresence>
        </div>
      </div>

      {/* Dynamic Crew Assignment Side Panel */}
      <div className="backdrop-blur-xl bg-white/5 border border-white/10 rounded-3xl p-5 shadow-xl space-y-4">
        {selectedFlight ? (
          <div className="space-y-4 font-sans">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div>
                <h3 className="font-extrabold text-white text-sm">Scheduler Panel</h3>
                <p className="text-[10px] text-cyan-405 uppercase font-bold tracking-wider mt-0.5 animate-pulse">
                  Assigned to Flight {selectedFlight.flightNumber}
                </p>
              </div>
              <button
                onClick={onClearSelectedFlight}
                className="p-1 rounded-lg bg-white/5 border border-white/10 text-slate-400 hover:text-white cursor-pointer transition-all"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Quick Conflict Overrides Dialog Popover */}
            <div className="flex items-center gap-2 mb-2">
              <button
                onClick={handleEmergencyAssign}
                disabled={eligibleStandbyCrew.length === 0}
                className="bg-red-500/20 border border-red-500/30 text-rose-400 hover:bg-red-500/30 font-bold text-xs py-1.5 px-3 rounded-lg shadow-sm transition-all cursor-pointer flex items-center gap-1.5 w-full justify-center disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <AlertTriangle className="w-3.5 h-3.5" />
                Emergency Assign Standby Crew
              </button>
            </div>

            {conflictWarning && (
              <div className="p-4 backdrop-blur-md bg-red-500/10 border border-red-500/20 rounded-2xl space-y-3 font-sans">
                <div className="flex items-start gap-2.5">
                  <AlertTriangle className="w-5 h-5 text-red-400 shrink-0 mt-0.5 animate-bounce" />
                  <div className="space-y-1">
                    <h4 className="text-xs font-bold text-white">Safety Compliance Warning</h4>
                    <p className="text-[11px] text-red-200 leading-relaxed font-sans">{conflictWarning.message}</p>
                  </div>
                </div>

                {currentUserRole === "Admin" ? (
                  <div className="flex justify-end gap-2 text-right pt-1">
                    <button
                      onClick={() => setConflictWarning(null)}
                      className="bg-white/10 hover:bg-white/15 text-white text-[10px] font-bold px-2.5 py-1.5 rounded transition-all cursor-pointer"
                    >
                      Bypass Assign
                    </button>
                    <button
                      onClick={handleApplyOverride}
                      className="bg-red-500 hover:bg-red-400 text-white text-[10px] font-extrabold px-2.5 py-1.5 rounded shadow-md transition-all cursor-pointer"
                    >
                      Override Constraints
                    </button>
                  </div>
                ) : (
                  <p className="text-[10px] text-red-300 font-medium">Bypass restricted. Only Administrators can authorize override safety exceptions.</p>
                )}
              </div>
            )}

            {/* Configured assigned crew cards */}
            <div className="space-y-3">
              <h4 className="text-xs font-bold text-cyan-455 uppercase tracking-wider">Assigned Members</h4>

              {assignedCrewList.length === 0 ? (
                <div className="p-4 border border-dashed border-white/10 rounded-2xl text-center text-slate-400 text-xs py-6 bg-white/[0.02]">
                  No personnel is currently assigned to this flight route.
                </div>
              ) : (
                <div className="space-y-2 font-sans">
                  <AnimatePresence mode="popLayout">
                    {assignedCrewList.map((crew) => (
                      <motion.div
                        layout
                        initial={{ opacity: 0, scale: 0.95, y: 5 }}
                        animate={{ opacity: 1, scale: 1, y: 0 }}
                        exit={{ opacity: 0, scale: 0.95, y: -5 }}
                        transition={{ duration: 0.15 }}
                        key={crew.id}
                        className="p-3 bg-white/[0.02] border border-white/5 hover:border-white/15 rounded-2xl flex items-center justify-between transition-all"
                      >
                        <div className="flex items-center gap-2.5">
                          <div className={`w-8 h-8 rounded-lg flex items-center justify-center text-xs font-bold text-white ${crew.avatarColor}`}>
                            {crew.name.split(" ").pop()?.charAt(0)}
                          </div>
                          <div>
                            <p className="text-xs font-bold text-white">{crew.name}</p>
                            <p className="text-[10px] text-slate-400 font-medium">{crew.role} ({crew.rank})</p>
                          </div>
                        </div>

                        {currentUserRole === "Admin" && (
                          <button
                            onClick={() => handleCrewAssignmentToggle(crew.id)}
                            className="p-1 px-2.5 backdrop-blur-md bg-red-500/5 hover:bg-red-500/15 border border-red-500/20 hover:border-red-500/30 text-rose-400 hover:text-rose-350 rounded-lg text-[10px] font-bold transition-all flex items-center gap-1 cursor-pointer"
                            title="Unassign staffing slot"
                          >
                            <UserMinus className="w-3.5 h-3.5 shrink-0" />
                            Deassigned
                          </button>
                        )}
                      </motion.div>
                    ))}
                  </AnimatePresence>
                </div>
              )}
            </div>

            {/* Standby roster options */}
            <div className="space-y-3 pt-2">
              <h4 className="text-xs font-bold text-cyan-455 uppercase tracking-wider">Standby Staff Pool</h4>
              <p className="text-[10px] text-slate-400 leading-tight">Eligible crew list on duty at SFO, JFK, or LAX bases.</p>

              <div className="max-h-68 overflow-y-auto space-y-2 border border-white/5 p-2 rounded-2xl bg-white/[0.02]">
                <AnimatePresence mode="popLayout">
                  {eligibleStandbyCrew.map((crew) => (
                    <motion.div
                      layout
                      initial={{ opacity: 0, scale: 0.95, y: 5 }}
                      animate={{ opacity: 1, scale: 1, y: 0 }}
                      exit={{ opacity: 0, scale: 0.95, y: -5 }}
                      transition={{ duration: 0.15 }}
                      key={crew.id}
                      className="p-2.5 bg-white/[0.012] border border-white/5 hover:border-cyan-400/30 hover:bg-white/5 rounded-xl flex items-center justify-between transition-all"
                    >
                      <div>
                        <h5 className="text-xs font-bold text-white leading-tight">{crew.name}</h5>
                        <div className="flex items-center gap-1.5 mt-1 text-[9px] font-bold text-slate-400">
                          <span>{crew.role}</span>
                          <span>•</span>
                          <span>{crew.baseAirport} Base</span>
                          <span>•</span>
                          <span className={`px-1.5 py-0.5 rounded border ${crew.flightHoursThisWeek >= 35 ? 'text-red-400 bg-red-500/15 border-red-500/15' : 'text-slate-350 bg-white/5 border-white/5'}`}>
                            {crew.flightHoursThisWeek}h week
                          </span>
                        </div>
                      </div>

                      {currentUserRole === "Admin" ? (
                        <button
                          onClick={() => handleCrewAssignmentToggle(crew.id)}
                          className="p-1 px-2.5 bg-cyan-500/10 hover:bg-cyan-500 border border-cyan-500/15 text-cyan-400 hover:text-white rounded-lg text-[10px] font-bold transition-all flex items-center gap-1.5 cursor-pointer"
                        >
                          <UserPlus className="w-3.5 h-3.5" /> Allocate
                        </button>
                      ) : (
                        <span className="text-[9px] uppercase font-bold text-slate-500">Lock</span>
                      )}
                    </motion.div>
                  ))}
                </AnimatePresence>
              </div>
            </div>
          </div>
        ) : (
          <div className="text-center py-12 text-slate-400 space-y-3">
            <Users className="w-10 h-10 text-slate-600 mx-auto animate-pulse" />
            <h4 className="font-bold text-white text-sm">Staff Duty Dispatch</h4>
            <p className="text-xs leading-relaxed max-w-[200px] mx-auto text-slate-400">
              Select any flight scheduling slot from the left database to query compliance, track violations, and allocate pilot/cabin crew rosters.
            </p>
          </div>
        )}
      </div>

      {/* Administrative Dispatch Flight Form Modal */}
      {isAdding && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
          <div className="backdrop-blur-3xl bg-slate-900/90 border border-white/10 rounded-3xl p-6 shadow-2xl max-w-lg w-full relative">
            <button
              onClick={() => setIsAdding(false)}
              className="absolute top-4 right-4 p-1.5 rounded-lg hover:bg-white/10 text-slate-400 hover:text-white transition-all cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <h3 className="font-bold text-white text-base mb-1">Dispatch Commercial Flight Route</h3>
            <p className="text-xs text-slate-400 mb-6 font-sans">Setup aircraft rotations and human resource staffing limits.</p>

            {formError && (
              <div className="mb-4 p-3 backdrop-blur-md bg-red-500/10 border border-red-500/20 text-red-200 rounded-xl text-xs flex items-center gap-2 font-sans">
                <AlertTriangle className="w-4 h-4 shrink-0" />
                <span>{formError}</span>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4 font-sans text-left">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] uppercase font-bold text-slate-350 mb-1">Flight Identifier Code</label>
                  <input
                    id="form-flight-number"
                    type="text"
                    required
                    value={formData.flightNumber}
                    onChange={(e) => setFormData({ ...formData, flightNumber: e.target.value.toUpperCase() })}
                    placeholder="e.g., SL-150"
                    className="w-full bg-white/5 border border-white/10 focus:border-cyan-400 focus:bg-white/10 focus:ring-1 focus:ring-cyan-500/20 rounded-xl py-2 px-3 text-xs text-white placeholder-white/20 outline-none transition-all uppercase"
                  />
                </div>

                <div>
                  <label className="block text-[10px] uppercase font-bold text-slate-350 mb-1">Equipment / Aircraft Type</label>
                  <select
                    id="form-aircraft"
                    value={formData.aircraftType}
                    onChange={(e) => setFormData({ ...formData, aircraftType: e.target.value })}
                    className="w-full bg-white/5 border border-white/10 rounded-xl py-2 px-3 text-xs text-slate-200 outline-none focus:border-cyan-400"
                  >
                    <option value="Boeing 737 Max" className="bg-slate-950">Boeing 737 Max</option>
                    <option value="Airbus A320" className="bg-slate-950">Airbus A320</option>
                    <option value="Boeing B787 Dreamliner" className="bg-slate-950">Boeing B787 Dreamliner</option>
                    <option value="Bombardier CRJ-900" className="bg-slate-950">Bombardier CRJ-900</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] uppercase font-bold text-slate-350 mb-1">Origin Port</label>
                  <select
                    id="form-origin"
                    value={formData.origin}
                    onChange={(e) => setFormData({ ...formData, origin: e.target.value })}
                    className="w-full bg-white/5 border border-white/10 rounded-xl py-2 px-3 text-xs text-slate-202 outline-none focus:border-cyan-400"
                  >
                    <option value="JFK" className="bg-slate-950">JFK (New York)</option>
                    <option value="LAX" className="bg-slate-950">LAX (Los Angeles)</option>
                    <option value="SFO" className="bg-slate-950">SFO (San Francisco)</option>
                    <option value="ORD" className="bg-slate-950">ORD (Chicago)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] uppercase font-bold text-slate-350 mb-1">Destination Port</label>
                  <select
                    id="form-destination"
                    value={formData.destination}
                    onChange={(e) => setFormData({ ...formData, destination: e.target.value })}
                    className="w-full bg-white/5 border border-white/10 rounded-xl py-2 px-3 text-xs text-slate-202 outline-none focus:border-cyan-400"
                  >
                    <option value="JFK" className="bg-slate-950">JFK (New York)</option>
                    <option value="LAX" className="bg-slate-950">LAX (Los Angeles)</option>
                    <option value="SFO" className="bg-slate-950">SFO (San Francisco)</option>
                    <option value="ORD" className="bg-slate-950">ORD (Chicago)</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] uppercase font-bold text-slate-350 mb-1">Departure Time (UTC)</label>
                  <input
                    id="form-dep-time"
                    type="datetime-local"
                    required
                    value={formData.departureTime}
                    onChange={(e) => setFormData({ ...formData, departureTime: e.target.value })}
                    className="w-full bg-white/5 border border-white/10 rounded-xl py-2 px-3 text-xs text-white placeholder-white/20 outline-none focus:border-cyan-400 focus:bg-white/10 transition-all font-sans"
                  />
                </div>

                <div>
                  <label className="block text-[10px] uppercase font-bold text-slate-350 mb-1">Arrival Time (UTC)</label>
                  <input
                    id="form-arr-time"
                    type="datetime-local"
                    required
                    value={formData.arrivalTime}
                    onChange={(e) => setFormData({ ...formData, arrivalTime: e.target.value })}
                    className="w-full bg-white/5 border border-white/10 rounded-xl py-2 px-3 text-xs text-white placeholder-white/20 outline-none focus:border-cyan-400 focus:bg-white/10 transition-all font-sans"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 border-t border-white/5 pt-4">
                <div>
                  <label className="block text-[10px] uppercase font-bold text-slate-350 mb-1">Required Pilots</label>
                  <input
                    id="form-req-pilots"
                    type="number"
                    min="1"
                    max="4"
                    required
                    value={formData.requiredPilots}
                    onChange={(e) => setFormData({ ...formData, requiredPilots: e.target.value })}
                    className="w-full bg-white/5 border border-white/10 rounded-xl py-2 px-3 text-xs text-white placeholder-white/20 outline-none focus:border-cyan-455"
                  />
                </div>

                <div>
                  <label className="block text-[10px] uppercase font-bold text-slate-350 mb-1">Required Attendants</label>
                  <input
                    id="form-req-cabin"
                    type="number"
                    min="1"
                    max="10"
                    required
                    value={formData.requiredCabinCrew}
                    onChange={(e) => setFormData({ ...formData, requiredCabinCrew: e.target.value })}
                    className="w-full bg-white/5 border border-white/10 rounded-xl py-2 px-3 text-xs text-white placeholder-white/20 outline-none focus:border-cyan-455"
                  />
                </div>
              </div>

              <div className="flex gap-3 pt-6">
                <button
                  type="button"
                  onClick={() => setIsAdding(false)}
                  className="flex-1 bg-white/5 border border-white/10 hover:bg-white/10 rounded-xl py-2.5 text-xs font-bold text-slate-300 transition-all cursor-pointer text-center"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="flex-1 bg-gradient-to-r from-blue-500 to-cyan-500 hover:opacity-90 rounded-xl py-2.5 text-xs font-bold text-white transition-all cursor-pointer text-center flex items-center justify-center shadow-lg shadow-cyan-500/10"
                >
                  {submitting ? "Processing Dispatch..." : "Confirm Flight Plan"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
